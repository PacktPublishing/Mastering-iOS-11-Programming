//
//  CustomPresentedViewController.swift
//  HelloContacts
//
//  Created by Donny Wals on 18/06/2017.
//  Copyright © 2017 DonnyWals. All rights reserved.
//

import UIKit

class CustomPresentedViewController: UIViewController, UIViewControllerTransitioningDelegate {
    var hideAnimator: CustomModalHideAnimator?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        transitioningDelegate = self
        hideAnimator = CustomModalHideAnimator(withViewController: self)
    }
    
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return CustomModalShowAnimator()
    }
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return hideAnimator
    }
    
    func interactionControllerForDismissal(using animator: UIViewControllerAnimatedTransitioning) -> UIViewControllerInteractiveTransitioning? {
        
        return hideAnimator
    }
}
