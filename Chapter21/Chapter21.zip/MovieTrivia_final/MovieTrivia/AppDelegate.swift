//
//  AppDelegate.swift
//  MovieTrivia
//
//  Created by Donny Wals on 15/10/2016.
//  Copyright © 2016 DonnyWals. All rights reserved.
//

import UIKit

typealias JSON = [String: Any]

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

}

