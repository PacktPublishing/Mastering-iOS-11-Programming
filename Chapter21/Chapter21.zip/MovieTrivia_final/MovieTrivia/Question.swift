//
//  Question.swift
//  MovieTrivia
//
//  Created by Donny Wals on 16/10/2016.
//  Copyright © 2016 DonnyWals. All rights reserved.
//

import Foundation

struct Question: Codable {
    
    enum CodingKeys: String, CodingKey {
        case title
        case answerA = "answer_a"
        case answerB = "answer_b"
        case answerC = "answer_c"
        case correctAnswer = "correct_answer"
    }
    
    let title: String
    let answerA: String
    let answerB: String
    let answerC: String
    let correctAnswer: Int
}
