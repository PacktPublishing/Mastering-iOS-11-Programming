//
//  ContactDisplayable.swift
//  HelloContacts
//
//  Created by Donny Wals on 20/06/2017.
//  Copyright © 2017 DonnyWals. All rights reserved.
//

import UIKit

protocol ContactDisplayable {
    var displayName: String { get }
    var contactImage: UIImage? { get set }
    
    mutating func fetchImageIfNeeded()
} 
