//
//  CompactViewControllerDelegate.swift
//  The Daily Quote
//
//  Created by Donny Wals on 01/10/2016.
//  Copyright © 2016 Donny Wals. All rights reserved.
//

import Foundation

protocol QuoteSelectionDelegate {
    func shareQuote(_ quote: Quote)
}
